
import java.util.*;
public class Admin extends Staff
{
	public void show()
	{
		System.out.println("\n\n---ADMIN---\nName:Rex\nID:LMS101");
	}
}
