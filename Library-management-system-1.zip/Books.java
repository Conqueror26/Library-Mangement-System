import java.util.*;
class Books extends Book
{
	String name,author;
	int ID;
	Books(){}
	Books(String name,String author,int ID)
	{
		this.name=name;
		this.author=author;
		this.ID=ID;
	}
}