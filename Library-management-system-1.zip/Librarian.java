import java.util.*;
public class Librarian extends Staff
{
	public void show()
	{
		System.out.println("\n---LIBRARIAN---\nName:Naveen Karthik\nID:LMS102");
	}
}