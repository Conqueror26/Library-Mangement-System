import java.util.*;
class Student extends User
{
	String name;
	int ID;
	Student(){}
	Student(String name,int ID)
	{
		this.name=name;
		this.ID=ID;
	}
}